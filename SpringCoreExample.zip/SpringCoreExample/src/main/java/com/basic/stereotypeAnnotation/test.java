package com.basic.stereotypeAnnotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {

	public static void main(String[] args) {
		ApplicationContext con= 
				new ClassPathXmlApplicationContext("com/basic/stereotypeAnnotation/configStereo.xml");

		/*Student student=con.getBean("student",Student.class);
		System.out.println(student);*/
		 
		Student stu=con.getBean("ob",Student.class);
		System.out.println(stu);
		System.out.println(stu.getAddress().getClass().getName());
		
	}

}
