package com.basic.standalone;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {
	public static void main(String[] args) {
		
		
		
		ApplicationContext context	=
				new ClassPathXmlApplicationContext("com/basic/standalone/configStandalone.xml");
	    
		Person per= context.getBean("person1",Person.class);
		System.out.println(per);
	    System.out.println(per.getFriends().getClass().getName());
	    System.out.println("----------------------------------");
	    System.out.println(per.getFeestructure()); 
	    System.out.println(per.getFeestructure().getClass().getName());
	  
	
	}

}
