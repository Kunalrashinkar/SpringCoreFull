package com.basic.lifecycle;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class PohaAnnotation {
	
	private String price;

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public PohaAnnotation() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "PohaAnnotation [price=" + price + "]";
	}
	
	@PostConstruct
	public void start()
	{
		System.out.println("Starting Method");
	}
	@PreDestroy
	public void end()
	{
		System.out.println("Ending Method");
	}

}
