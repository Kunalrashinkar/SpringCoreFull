package com.basic.lifecycle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {

	public static void main(String[] args) {
		
		/*ApplicationContext con=
		new ClassPathXmlApplicationContext("com/basic/lifecycle/configLifecycle.xml");*/
       
		
		//for calling destroy() we use AbstractApplicationContext
		AbstractApplicationContext con=
				new ClassPathXmlApplicationContext("com/basic/lifecycle/configLifecycle.xml");
		
		SamosaXml sam=(SamosaXml) con.getBean("s1");
		
		System.out.println(sam);
		
		//for enable methods registering Shutdown hook
		
		con.registerShutdownHook();
		
		System.out.println("_____________________________________________________");
		
		PepsiInterface pep= (PepsiInterface) con.getBean("p");
		System.out.println(pep);
		
		
		
		
		
	}

}
