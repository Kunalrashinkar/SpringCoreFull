package com.basic.lifecycle;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class testPoha {

	public static void main(String[] args) {
		
		AbstractApplicationContext con= new ClassPathXmlApplicationContext("com/basic/lifecycle/configLifecycle.xml");
		
		con.registerShutdownHook();
		PohaAnnotation pa=(PohaAnnotation) con.getBean("po");
		System.out.println(pa);

	}

}
