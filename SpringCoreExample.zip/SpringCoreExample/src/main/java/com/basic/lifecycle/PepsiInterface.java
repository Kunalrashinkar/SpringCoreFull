package com.basic.lifecycle;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class PepsiInterface implements InitializingBean ,DisposableBean {
	
	private double price;

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public PepsiInterface() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Pepsi [price=" + price + "]";
	}

	public void afterPropertiesSet() throws Exception {
		
		//for init 
		
		System.out.println("Taking Pepsi: init");
	}

	public void destroy() throws Exception {
		
		//For Destroy
		
		System.out.println("Going to put Pepsi in Container: Destroy");
		
	}
	
	

}
