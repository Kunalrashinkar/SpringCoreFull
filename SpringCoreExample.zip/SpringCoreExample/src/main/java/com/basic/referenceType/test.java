package com.basic.referenceType;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {

	public static void main(String[] args) {
	ApplicationContext context	=
			new ClassPathXmlApplicationContext("com/basic/referenceType/configRefrence.xml");
		A a= (A)context.getBean("aref");
        System.out.println(a.getX());
        
        B b=(B) context.getBean("bref");
        System.out.println(a.getOb().getY());
	}

}
