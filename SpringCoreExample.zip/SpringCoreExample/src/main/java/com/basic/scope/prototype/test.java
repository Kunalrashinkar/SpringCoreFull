package com.basic.scope.prototype;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {

	public static void main(String[] args) {
		ApplicationContext con= 
				new ClassPathXmlApplicationContext("com/basic/scope/prototype/configScope.xml");

		/*Student student=con.getBean("student",Student.class);
		System.out.println(student);*/
		 
		Student stu=con.getBean("ob",Student.class);
		/*System.out.println(stu);
		System.out.println(stu.getAddress().getClass().getName());
		*/
		
		System.out.println(stu.hashCode());
		
		Student stu1=con.getBean("ob",Student.class);
		System.out.println(stu1.hashCode());
		
		Teacher tea=con.getBean("teacher",Teacher.class);
		
		System.out.println(tea.hashCode());
		
      Teacher tea1=con.getBean("teacher",Teacher.class);
		
		System.out.println(tea1.hashCode());
		
		
		
	}

}
