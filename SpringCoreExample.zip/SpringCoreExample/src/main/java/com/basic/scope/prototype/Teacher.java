package com.basic.scope.prototype;

public class Teacher {
	
	

}
